#include <iostream>
#include "MyDll.h"

#pragma comment(lib,"MyDll.lib")

using namespace std;

int main()
{
	CMyDll mydll;
	int ret = mydll.MyPrint();
	cout << "ret=" << ret << endl;
	system("pause");
	return 0;
}